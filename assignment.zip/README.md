<h2>To run the code:</h2>

```bash
pip install -r requirements.txt
python news_analysis.py
```